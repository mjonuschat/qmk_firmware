Overview
========

This is my personal ErgoDox configuration, and my daily driver.

Most of the code resides in my userspace, rather than here, as I have multiple keyboards.

How to build 
------------
qmk compile -kb input_club/ergodox_infinity -km mjonuschat

Layers
------
* NEO_1/NEO_3/NEO_4: basic NEO layout
* FKEYS: F keys across the top, media keys on the left/rightmost column
