// Copyright 2021 Morton Jonuschat <mjonuschat@gmail.com>
// SPDX-License-Identifier: GPL-2.0-or-later

#pragma once

#ifdef MANUFACTURER
#    undef MANUFACTURER
#endif
#define MANUFACTURER "Ergohaven"

#define MASTER_LEFT
#define ONESHOT_TAP_TOGGLE 3

/* Encoder support */
#define ENCODER_A_PINS { F5 }
#define ENCODER_B_PINS { F4 }
#define ENCODER_A_PINS_RIGHT { F4 }
#define ENCODER_B_PINS_RIGHT { F5 }
#define ENCODER_RESOLUTION 2
#define ENCODER_DIRECTION_FLIP

// Underglow
#ifdef WS2812_DI_PIN
#    undef WS2812_DI_PIN
#endif
#define WS2812_DI_PIN D1

#ifdef RGBLIGHT_LED_COUNT
#    undef RGBLIGHT_LED_COUNT
#endif
#define RGBLIGHT_LED_COUNT 20

#define RGBLED_SPLIT { 10, 10 }
#define WS2812_RGBW
#define WS2812_BYTE_ORDER WS2812_BYTE_ORDER_GRB
#define RGBLIGHT_SLEEP
#define RGBLIGHT_LIMIT_VAL 150
