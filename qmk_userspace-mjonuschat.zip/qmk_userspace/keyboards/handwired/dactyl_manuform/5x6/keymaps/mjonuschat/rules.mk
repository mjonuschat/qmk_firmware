NEO_RMOD3_ANSI		= yes
ENCODER_ENABLE 		= yes
EXTRAKEY_ENABLE 	= yes
RGBLIGHT_ENABLE 	= yes

# RP2040 build target (see qmk.json): upstream's keyboard.json names the AVR
# chip directly instead of the Pro Micro footprint, so declare it here to let
# CONVERT_TO=sparkfun_pm2040 work. Has no effect on the default Pro Micro build.
PIN_COMPATIBLE = promicro
