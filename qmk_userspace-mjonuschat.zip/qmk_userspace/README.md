# mjonuschat's QMK Userspace

Keymaps and shared userspace code for:

| Keyboard | Keymap location | Build |
|---|---|---|
| ErgoDox Infinity | `layouts/ergodox/mjonuschat` | `qmk compile -kb input_club/ergodox_infinity -km mjonuschat` |
| Dactyl Manuform 5x6 (Ergohaven) | `keyboards/handwired/dactyl_manuform/5x6/keymaps/mjonuschat` | `qmk compile -kb handwired/dactyl_manuform/5x6 -km mjonuschat` |
| GMMK Pro rev1 ANSI | `keyboards/gmmk/pro/rev1/ansi/keymaps/mjonuschat` | `qmk compile -kb gmmk/pro/rev1/ansi -km mjonuschat` |

Shared code lives in `users/mjonuschat`. All three targets are listed in `qmk.json`,
so `qmk userspace-compile` builds everything and GitHub Actions publishes firmware
to the Releases tab on every push.

## Getting started

This folder is already a git repository on `main` with one commit.

### Publish to GitHub

1. Create an **empty** repository on GitHub, e.g. `mjonuschat/qmk_userspace`
   (no README, license or `.gitignore`, so the first push doesn't conflict).
2. From inside this folder, add it as the remote and push:

   ```bash
   git remote add origin git@github.com:mjonuschat/qmk_userspace.git
   ```

   ```bash
   git push -u origin main
   ```

3. In the repository's **Actions** tab, enable workflows. Every push then builds
   all three keyboards against QMK `master`, and the firmware files appear on
   the **Releases** page.

### Build locally

You need a working QMK setup first (`qmk setup`; see the
[QMK docs](https://docs.qmk.fm/newbs)). Then point QMK at this folder, run from
the folder that contains `qmk_userspace`:

```bash
qmk config user.overlay_dir="$(realpath qmk_userspace)"
```

Build everything listed in `qmk.json`:

```bash
qmk userspace-compile
```

Or build a single keyboard, for example:

```bash
qmk compile -kb input_club/ergodox_infinity -km mjonuschat
```

`qmk userspace-doctor` checks that QMK finds this folder, and
`qmk userspace-list` shows the build targets.

### Before flashing

* None of these builds have been tested on real hardware yet. Check each board
  after flashing it.
* **Dactyl Manuform:** the old keymap defined its own `OS_RGUI` as
  `OSM(MOD_LGUI)`, so that key sent *left* GUI. The port keeps that by using
  `OS_LGUI` in that position. If that was a typo and you meant right GUI, change
  it to `OS_RGUI` in
  `keyboards/handwired/dactyl_manuform/5x6/keymaps/mjonuschat/keymap.c`.

## Migration notes

Moved from the `userspace-mjonuschat` branch of the `qmk_firmware` fork (based on
QMK from August 2022) and ported to QMK `master` `f5db96211` (2026-10-29):

* Renamed keycodes: `KC_LCTRL`/`KC_LSHIFT`/`KC_BSPACE`/... to their short forms,
  `RESET` to `QK_BOOT`, `KC_LEAD` to `QK_LEAD`, `UC_MOD` to `UC_NEXT`, and RGB matrix
  keys on the GMMK Pro to `RM_*`.
* Unicode modes: `UC_LNX`/`UC_WINC` to `UNICODE_MODE_LINUX`/`UNICODE_MODE_WINCOMPOSE`.
* Callback signatures: `rgb_matrix_indicators[_advanced]_user` and `shutdown_user`
  now return `bool`; removed `startup_user()` call; `rgblight_setrgb_red()` to
  `rgblight_setrgb(RGB_RED)`.
* ST7565 lock indicators use `host_keyboard_led_state()` instead of `USB_LED_*` masks.
* Leader key uses `leader_end_user()` + `leader_sequence_*_keys()`.
* Config renames: `RGB_DI_PIN` to `WS2812_DI_PIN`, `RGBLED_NUM` to `RGBLIGHT_LED_COUNT`,
  `RGBW` to `WS2812_RGBW`, `ENCODERS_PAD_*` to `ENCODER_*_PINS`, `USE_SERIAL` removed,
  `RGB_MATRIX_STARTUP_MODE` to `RGB_MATRIX_DEFAULT_MODE`,
  `RGB_DISABLE_WHEN_USB_SUSPENDED` to `RGB_MATRIX_SLEEP`, `MANUFACTURER` is now a string.
* Dactyl: the old local `OS_RGUI` sent *left* GUI and clashed with QMK's own
  `OS_RGUI`; the keymap now uses `OS_LGUI` in that position to keep the old behaviour.

---

## About this template

This is a template repository which allows for an external set of QMK keymaps to be defined and compiled. This is useful for users who want to maintain their own keymaps without having to fork the [main QMK repository](https://github.com/qmk/qmk_firmware). You must still fork the main QMK repository if writing firmware for a *new* keyboard.

## Howto configure your build targets

1. Run the normal `qmk setup` procedure if you haven't already done so -- see [QMK Docs](https://docs.qmk.fm/#/newbs) for details.
1. Fork this repository
1. Clone your fork to your local machine
1. Enable userspace in QMK config using `qmk config user.overlay_dir="$(realpath qmk_userspace)"`
1. Add a new keymap for your board using `qmk new-keymap`
    * This will create a new keymap in the `keyboards` directory, in the same location that would normally be used in the main QMK repository. For example, if you wanted to add a keymap for the Planck, it will be created in `keyboards/planck/keymaps/<your keymap name>`
    * You can also create a new keymap using `qmk new-keymap -kb <your_keyboard> -km <your_keymap>`
    * Alternatively, add your keymap manually by placing it in the location specified above.
    * `layouts/<layout name>/<your keymap name>/keymap.*` is also supported if you prefer the layout system
1. Add your keymap(s) to the build by running `qmk userspace-add -kb <your_keyboard> -km <your_keymap>`
    * This will automatically update your `qmk.json` file
    * Corresponding `qmk userspace-remove -kb <your_keyboard> -km <your_keymap>` will delete it
    * Listing the build targets can be done with `qmk userspace-list`
1. Commit your changes

## Howto build with GitHub

1. In the GitHub Actions tab, enable workflows
1. Push your changes above to your forked GitHub repository
1. Look at the GitHub Actions for a new actions run
1. Wait for the actions run to complete
1. Inspect the Releases tab on your repository for the latest firmware build

## Howto build locally

1. Run the normal `qmk setup` procedure if you haven't already done so -- see [QMK Docs](https://docs.qmk.fm/#/newbs) for details.
1. Fork this repository
1. Clone your fork to your local machine
1. `cd` into this repository's clone directory
1. Set global userspace path: `qmk config user.overlay_dir="$(realpath .)"` -- you MUST be located in the cloned userspace location for this to work correctly
    * This will be automatically detected if you've `cd`ed into your userspace repository, but the above makes your userspace available regardless of your shell location.
1. Compile normally: `qmk compile -kb your_keyboard -km your_keymap` or `make your_keyboard:your_keymap`

Alternatively, if you configured your build targets above, you can use `qmk userspace-compile` to build all of your userspace targets at once.

## Extra info

If you wish to point GitHub actions to a different repository, a different branch, or even a different keymap name, you can modify `.github/workflows/build_binaries.yml` to suit your needs.

To override the `build` job, you can change the following parameters to use a different QMK repository or branch:
```
    with:
      qmk_repo: qmk/qmk_firmware
      qmk_ref: master
```

If you wish to manually manage `qmk_firmware` using git within the userspace repository, you can add `qmk_firmware` as a submodule in the userspace directory instead. GitHub Actions will automatically use the submodule at the pinned revision if it exists, otherwise it will use the default latest revision of `qmk_firmware` from the main repository.

This can also be used to control which fork is used, though only upstream `qmk_firmware` will have support for external userspace until other manufacturers update their forks.

1. (First time only) `git submodule add https://github.com/qmk/qmk_firmware.git`
1. (To update) `git submodule update --init --recursive`
1. Commit your changes to your userspace repository
